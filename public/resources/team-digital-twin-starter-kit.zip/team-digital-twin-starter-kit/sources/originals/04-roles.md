# Team roles

Status: Approved by the fictional team for this exercise.
Amara: Workshop lead. Approves capacity, spending and public release.
Leo: Facilitator. Designs and teaches the workshop, and checks learning quality.
Noor: Host liaison. Seeks venue confirmation; may not commit the team to a venue contract.
Sam: Operations. Drafts budgets and checks documents. A role does not assign a new task without acceptance.
