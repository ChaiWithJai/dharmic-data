# What good looks like

Status: Approved by Leo and Amara for this exercise.
Acceptable example: "The library garden opened in 1998, according to the plaque I photographed. My memory of helping plant it is personal recollection, not a verified fact."
Quality rule: A finished story distinguishes checked facts from recollection, identifies its evidence and has its author's permission to share.
Stop rule: Conflicting instructions and tasks without an accepted owner remain visible for a human decision.
