# Meeting notes

Status: Draft notes. Amara has not approved these changes.
Capacity note: "We agreed to open 18 places."
Invitation note: "Sam could draft the invitation." This is a suggestion; the task has no accepted owner.
