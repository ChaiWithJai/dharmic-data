# Approved workshop brief

Approval: Amara approved this baseline for the fictional exercise.
Outcome: Every participant leaves with a 150-word neighborhood story that they have checked and chosen to share.
Format: One 90-minute workshop for 12 adults.
Budget ceiling: USD 390.
Boundary: Use invented or explicitly volunteered stories; no participant contact details or private recordings go into an AI tool.
