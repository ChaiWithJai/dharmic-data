# Neighborhood Stories: team context

**Synthetic demonstration. This packet is a draft awaiting human review.** It was manually curated; no AI extraction or production outcome is claimed. The approvals below are facts inside the fictional scenario, not real people's approvals.

## Approved baseline

We are four colleagues preparing one 90-minute workshop for 12 adults. Each participant should leave with a 150-word neighborhood story that they have checked and chosen to share. The spending ceiling is $390. These details come from the approved brief, not from a merged average of documents. [brief-approval, outcome, format-baseline, spending-ceiling]

Amara approves capacity, spending and publication. Leo designs and teaches the workshop and checks learning quality. Noor seeks a venue but cannot commit a contract. Sam drafts budgets and checks documents; new work still needs an accepted owner. [role-amara, role-leo, role-noor, role-sam]

Use invented or explicitly volunteered stories. Keep participant contact details and private recordings out of AI tools. A finished story separates checked facts from recollection, gives evidence and has its author's permission to share. [data-boundary, quality-rule]

## Assumption to confirm

The budget assumes a donated venue. A zero in a spreadsheet is not evidence that a host has agreed. Noor's role permits asking, not signing. Venue availability and any resulting cost need confirmation. [venue-assumption, role-noor]

## Unresolved decision: 12 or 18 places?

The approved brief says **12 adults**. The unapproved meeting note says **“We agreed to open 18 places.”** Both remain in the record. More recent notes do not automatically override an approved brief. [format-baseline, capacity-draft, notes-status]

Materials cost $7.50 per person. The current materials line is $90 for 12. At 18 it would be $135, adding **$45** and bringing the scenario total to **$435**, assuming every other line stays the same. That exceeds the $390 ceiling. This is transparent arithmetic, not a forecast or a new approval. [materials, facilitation, refreshments, venue-assumption, spending-ceiling]

**Decision requested:** Amara should choose the capacity and approve any revised spending before invitations describe 18 places. The suggested expansion remains a draft. No deadline has been invented.

## Unassigned work

“Sam could draft the invitation” is a suggestion. The invitation task's owner is **unassigned** until someone accepts. Sam's operations role does not turn that suggestion into a commitment. [invitation-suggestion, role-sam]

## How to review this packet

Open `claims.json` for exact source lines and hashes. Correct a claim by recording a new decision or source version; do not edit the preserved originals to hide disagreement. A human should approve the packet, its intended audience and any externally shared output before use. The kit contains public synthetic examples only; that does not authorize sharing a real team's files.
