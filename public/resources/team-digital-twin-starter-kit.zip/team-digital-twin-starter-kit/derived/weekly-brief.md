# Weekly brief: Neighborhood Stories

**DRAFT — fictional, manually curated example. Not sent to anyone.**

## Known

- The approved plan is one 90-minute workshop for 12 adults, with a $390 spending ceiling. [format-baseline, spending-ceiling]
- The purpose is a checked, shareable 150-word story for each participant. [outcome, quality-rule]
- The budget reserves $90 for materials, $240 for facilitation and $60 for refreshments. The venue is assumed donated, not confirmed. [materials, facilitation, refreshments, venue-assumption]

## Proposed

- Draft meeting notes propose 18 places. At the existing materials rate, that adds $45 and produces a $435 scenario total if other lines stay unchanged. The expansion and extra spending have not been approved. [capacity-draft, notes-status, materials, spending-ceiling]
- Sam was suggested as the invitation drafter. This is not an accepted assignment. [invitation-suggestion]

## Needs a decision

1. **Capacity and money — Amara:** retain 12 places or approve a revised plan before an invitation promises 18. Amara's approval authority is documented. [role-amara]
2. **Invitation ownership — unassigned:** ask for an owner to accept. Do not silently assign it to Sam. [invitation-suggestion, role-sam]
3. **Venue — confirmation needed:** Noor's role covers seeking confirmation; a zero-cost assumption is not a booking. [venue-assumption, role-noor]

## Protected review time

Proposal for the team to accept or amend: spend 15 minutes resolving these three items together before generating more collateral. This timebox is an author suggestion, not a recorded team agreement or measured time saving.

Source trail: `claims.json` → `source-manifest.json` → unchanged files in `sources/originals/`.
