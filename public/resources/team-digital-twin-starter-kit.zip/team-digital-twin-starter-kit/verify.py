#!/usr/bin/env python3
"""Verify the synthetic teaching packet; no network, AI runtime or dependencies."""
from __future__ import annotations

import copy
import csv
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED_SOURCES = {
    "sources/originals/01-workshop-brief.md",
    "sources/originals/02-meeting-notes.md",
    "sources/originals/03-budget.csv",
    "sources/originals/04-roles.md",
    "sources/originals/05-quality-example.md",
}


def validate(manifest: dict, packet: dict) -> list[str]:
    """Return precise errors. This is a demonstration schema, not a truth oracle."""
    errors: list[str] = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    check(manifest.get("schema_version") == "1.0", "Manifest schema_version must be 1.0.")
    check(packet.get("schema_version") == "1.0", "Claims schema_version must be 1.0.")
    check(manifest.get("example_only") is True and packet.get("example_only") is True,
          "Both artifacts must identify the synthetic example.")
    check(packet.get("authoring_method") == "manual curation", "Do not relabel manual curation as model extraction.")
    check(packet.get("packet_status") == "draft" and packet.get("approved_for_use") is False,
          "The packet must not promote itself to approved.")
    check(packet.get("exclusions") == [], "This example includes all source content; an exclusion needs explicit redesign and review.")

    items = manifest.get("files", [])
    check(isinstance(items, list), "Manifest files must be a list.")
    if not isinstance(items, list):
        return errors
    paths = [item.get("path") for item in items]
    actual = {p.relative_to(ROOT).as_posix() for p in (ROOT / "sources/originals").rglob("*") if p.is_file()}
    check(len(paths) == len(set(paths)), "Duplicate source paths in manifest.")
    check(set(paths) == actual == EXPECTED_SOURCES, "Source inventory mismatch: no added, missing or silently excluded source is allowed.")
    sources = {}
    for item in items:
        path = item.get("path")
        if path not in EXPECTED_SOURCES:
            errors.append(f"Unrecognized source path: {path!r}.")
            continue
        if not (ROOT / path).is_file():
            errors.append(f"Source file is missing: {path}.")
            continue
        raw = (ROOT / path).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        check(item.get("sha256") == digest, f"Source hash mismatch: {path}.")
        check(item.get("bytes") == len(raw), f"Source byte count mismatch: {path}.")
        check(item.get("selection") == "included", f"Source excluded without review: {path}.")
        check(item.get("permission") == "public synthetic", f"Unexpected permission scope: {path}.")
        sources[path] = {"lines": raw.decode("utf-8").splitlines(), "sha256": digest, "manifest": item}

    claims = packet.get("claims", [])
    check(isinstance(claims, list), "Claims must be a list.")
    if not isinstance(claims, list):
        return errors
    ids = [c.get("id") for c in claims]
    check(all(isinstance(cid, str) and cid for cid in ids), "Every claim needs a nonempty ID.")
    check(len(ids) == len(set(ids)), "Duplicate claim ID.")
    by_id = {c.get("id"): c for c in claims}
    reference_coverage: dict[tuple[str, int], set[str]] = {}
    for claim in claims:
        cid = claim.get("id")
        check({"id", "statement", "approval_status", "value", "evidence"}.issubset(claim), f"Missing required claim field: {cid}.")
        check(isinstance(claim.get("statement"), str) and bool(claim.get("statement")), f"Empty claim statement: {cid}.")
        check(claim.get("approval_status") in {"approved", "unapproved", "planning_assumption"}, f"Unknown approval status: {cid}.")
        evidence = claim.get("evidence", [])
        check(isinstance(evidence, list) and bool(evidence), f"Claim lacks evidence: {cid}.")
        if not isinstance(evidence, list):
            continue
        for ref in evidence:
            path = ref.get("path")
            if path not in sources:
                errors.append(f"Unknown source in claim {cid}: {path!r}.")
                continue
            source = sources[path]
            start, end = ref.get("start_line"), ref.get("end_line")
            valid_span = isinstance(start, int) and isinstance(end, int) and 1 <= start <= end <= len(source["lines"])
            check(valid_span, f"Invalid evidence line span in {cid}.")
            if not valid_span:
                continue
            quote = "\n".join(source["lines"][start - 1:end])
            check(ref.get("quote") == quote, f"Evidence quote mismatch: {cid}.")
            check(ref.get("sha256") == source["sha256"], f"Evidence source hash mismatch: {cid}.")
            for line in range(start, end + 1):
                reference_coverage.setdefault((path, line), set()).add(cid)

    for path, source in sources.items():
        covered = set()
        for coverage in source["manifest"].get("coverage", []):
            start, end = coverage.get("start_line"), coverage.get("end_line")
            valid_span = isinstance(start, int) and isinstance(end, int) and 1 <= start <= end <= len(source["lines"])
            check(valid_span, f"Invalid inventory line span: {path}.")
            if not valid_span:
                continue
            for line in range(start, end + 1):
                check(line not in covered, f"Duplicate coverage entry: {path}:{line}.")
                covered.add(line)
                text = source["lines"][line - 1]
                if coverage.get("disposition") == "structure":
                    check(text.startswith("# ") or (path.endswith(".csv") and line == 1), f"Content mislabeled as structure: {path}:{line}.")
                    check(bool(coverage.get("reason")), f"Structure exclusion has no reason: {path}:{line}.")
                elif coverage.get("disposition") == "represented":
                    declared = set(coverage.get("claim_ids", []))
                    check(bool(declared) and declared == reference_coverage.get((path, line), set()), f"Content coverage mismatch: {path}:{line}.")
                else:
                    errors.append(f"Unexplained omission at {path}:{line}.")
        nonblank = {line for line, text in enumerate(source["lines"], 1) if text.strip()}
        check(covered == nonblank, f"Uninventoried content lines: {path}.")

    baseline = by_id.get("format-baseline", {})
    draft = by_id.get("capacity-draft", {})
    check(baseline.get("value", {}).get("capacity") == 12 and baseline.get("approval_status") == "approved", "The 12-place approved baseline was changed or demoted.")
    check(draft.get("value", {}).get("capacity") == 18 and draft.get("approval_status") == "unapproved", "The 18-place draft was lost or promoted to approved.")
    conflicts = packet.get("conflicts", [])
    check(len(conflicts) == 1, "The unresolved capacity conflict must remain explicit.")
    if conflicts:
        conflict = conflicts[0]
        check(conflict.get("id") == "capacity-12-or-18" and set(conflict.get("claim_ids", [])) == {"format-baseline", "capacity-draft"}, "Capacity conflict lost one of its sources.")
        check(conflict.get("status") == "unresolved" and conflict.get("resolution") is None, "Capacity was silently resolved.")
        check(conflict.get("decision_authority") == "Amara" and conflict.get("authority_claim_id") == "role-amara", "Capacity authority must point to Amara's documented role.")
    tasks = packet.get("tasks", [])
    check(len(tasks) == 1 and tasks[0].get("id") == "draft-invitation", "The unassigned invitation task must remain visible.")
    for task in tasks:
        check(task.get("accepted_owner") is None and task.get("owner_accepted") is False and task.get("status") == "proposed", "An unapproved invitation owner was promoted.")
        check(task.get("proposed_owner") == "Sam", "Preserve Sam as a suggestion, not an assignment.")
        check(set(task.get("claim_ids", [])) == {"invitation-suggestion", "role-sam"}, "Task evidence is incomplete.")

    with (ROOT / "sources/originals/03-budget.csv").open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        check(Decimal(row["units"]) * Decimal(row["unit_cost_usd"]) == Decimal(row["total_usd"]), f"Budget row arithmetic is wrong: {row['item']}.")
    baseline_total = sum(Decimal(row["total_usd"]) for row in rows)
    materials = rows[0]
    draft_materials = Decimal("18") * Decimal(materials["unit_cost_usd"])
    difference = draft_materials - Decimal(materials["total_usd"])
    scenario = baseline_total + difference
    calculations = packet.get("calculations", [])
    check(len(calculations) == 1, "The cost scenario must be explicit.")
    if calculations:
        calc = calculations[0]
        check(calc.get("status") == "hypothetical, unapproved" and bool(calc.get("assumption")), "Scenario lost its approval or assumption warning.")
        expected = {"baseline_total_usd": baseline_total, "draft_materials_usd": draft_materials, "incremental_materials_usd": difference, "scenario_total_usd": scenario}
        for field, amount in expected.items():
            check(calc.get(field) == f"{amount:.2f}", f"Scenario arithmetic mismatch: {field}.")
        check(all(cid in by_id for cid in calc.get("input_claim_ids", [])), "Cost scenario has a missing input claim.")

    for name in ["team-context.md", "weekly-brief.md"]:
        text = (ROOT / "derived" / name).read_text()
        for group in re.findall(r"\[([a-z][a-z0-9,-]*(?: [a-z0-9,-]+)*)\]", text):
            for cid in [part.strip() for part in group.split(",")]:
                check(cid in by_id, f"Unknown readable citation in {name}: {cid}.")
        check("unassigned" in text.lower() and "$45" in text and "$435" in text,
              f"Readable brief lost ownership or cost decision: {name}.")
        check("draft" in text.lower() and "fictional" in text.lower(), f"Readable brief lost its draft/example label: {name}.")
    return errors


def main() -> int:
    try:
        manifest = json.loads((ROOT / "derived/source-manifest.json").read_text())
        packet = json.loads((ROOT / "derived/claims.json").read_text())
        errors = validate(manifest, packet)
        negative = []
        mutations = [
            ("changed source hash", lambda m, p: m["files"][0].update(sha256="0" * 64)),
            ("silently excluded source", lambda m, p: m["files"].pop()),
            ("fabricated quote", lambda m, p: p["claims"][0]["evidence"][0].update(quote="Invented approval.")),
            ("missing content claim", lambda m, p: p["claims"].pop()),
            ("erased disagreement", lambda m, p: p.update(conflicts=[])),
            ("unaccepted owner promoted", lambda m, p: p["tasks"][0].update(accepted_owner="Sam", owner_accepted=True, status="assigned")),
            ("incorrect budget scenario", lambda m, p: p["calculations"][0].update(scenario_total_usd="390.00")),
        ]
        for name, mutate in mutations:
            test_manifest, test_packet = copy.deepcopy(manifest), copy.deepcopy(packet)
            mutate(test_manifest, test_packet)
            detected = validate(test_manifest, test_packet)
            negative.append({"case": name, "rejected": bool(detected), "first_error": detected[0] if detected else None})
            if not detected:
                errors.append(f"Negative check failed to reject: {name}.")
        report = {
            "checked_at_utc": datetime.now(timezone.utc).isoformat(),
            "result": "PASS" if not errors else "FAIL",
            "scope": "Manually curated synthetic example integrity; not model performance, real-world truth or permission verification.",
            "source_files": len(manifest.get("files", [])),
            "curated_claims": len(packet.get("claims", [])),
            "negative_checks": negative,
            "errors": errors,
        }
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
        report = {"result": "FAIL", "errors": [f"Invalid or unreadable packet: {exc}"]}
    (ROOT / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
