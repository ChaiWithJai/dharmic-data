# Ordinary files → useful team context

A companion to **Turn your team's files into gold: Build your team's digital twin with GPT-6 Astra + local AI**.

Here a *team digital twin* means a maintained, permissioned working model of the team's goals, roles, decisions, standards and context. It is not a replica of a person, a new source of truth, or permission to monitor colleagues. The people remain in charge.

## Start in five minutes

1. Open `sources/originals/01-workshop-brief.md` and `02-meeting-notes.md`. One says 12 places; the other says 18. Which should a polished invitation promise? The correct next step is a decision, not a confident guess.
2. Open `derived/weekly-brief.md`. Notice the Known, Proposed and Needs a decision sections. The $45 difference is useful; erasing the disagreement would be harmful.
3. Open `derived/team-context.md` for the reusable context. It is a draft, even though it describes an approved baseline within the fictional scenario.
4. Run `python3 verify.py` from this folder. It uses only the Python standard library and writes `verification.json`.
5. Try the prompts with this public synthetic example first. A model's output should preserve the disagreement and leave the invitation owner unassigned. Then choose one real workflow with your team, decide permissions and preserve its originals before experimenting.

## What is here

| Folder or file | Purpose |
| --- | --- |
| `sources/originals/` | Five unchanged fictional files: brief, meeting note, budget, roles and a quality example. |
| `derived/source-manifest.json` | Computed file hashes, source permissions and a line coverage inventory. |
| `derived/claims.json` | Manually curated claims with exact quotes, source lines, approval status, unresolved conflict and unassigned task. |
| `derived/team-context.md` | Readable reusable context, with assumptions and disagreement intact. |
| `derived/weekly-brief.md` | The small deliverable: known facts, proposals and decisions. |
| `prompts/` | Separate prompts for local extraction, Astra's planning review and human approval. |
| `accounting/` | An empty ledger plus a clearly labeled illustrative row. |
| `verify.py` | Checks source integrity, reference validity, coverage and the example's invariants. |

## What the demonstration proves

The verifier checks that the five preserved files match recorded SHA-256 hashes; every content line is represented; claim quotes match their line spans; the 12-versus-18 disagreement is still unresolved; no unapproved invitation owner was promoted; and the $390/$435 arithmetic is consistent with the source budget. It also runs negative checks against altered copies in memory to show those checks reject common mistakes.

It does **not** prove that an AI can extract this data, that a claim is true in the real world, that someone actually consented, or that this workflow improves a real team's productivity. The kit was manually authored as a synthetic teaching example. The hashes and checks are computed; the claims and briefs are curated. No actual participant data, customer result, model benchmark or economic benefit is represented here.

## Transfer the method to real work

Begin with one repeatable deliverable, such as a weekly handoff. Ask the team which files and recipients are allowed. Keep originals intact, including a stable version and hash. Capture source authority, date, audience and unresolved questions before summarizing. A decision recorded later may supersede an earlier claim; preserve both and link the decision.

Use a tested local model for bounded extraction only when its output can be checked. Use Astra for authorized synthesis and ambiguity analysis. Ask a person when the issue is authority, consent or missing information. Re-run source and reference checks after each revision, then review the actual content before sharing.

If working with real files, extend the schema for access restrictions, document dates, reviewers, retention and updates. This starter kit has only public synthetic sources. It is intentionally not a production document-management system or an access-control implementation.

## Measure the benefit before claiming it

Use the blank ledger for actual runs. Record model, device, elapsed time, human review time, corrections and acceptance. Measure recurring work before and after with the same quality criteria. Track repeated explanations and rework, then ask whether the team actually likes the resulting work more. Protect review and learning time rather than treating it as wasted effort.

Keep cash, subscriptions, electricity and hardware allocation distinct. Missing cost or token data stays blank and is explained; do not convert unknowns to zeros. A Codex subscription is development tooling, not an application API entitlement. AI assistance does not itself solve low pay: decide with the team how any verified gains translate into compensation, ownership, learning time or reduced load.

## Refresh rule

Choose a context steward and a review cadence with your real team. When an important source changes, mark dependent claims stale and ask for review. Do not append every chat forever. Preserve a useful decision trail and archive superseded context according to the team's permissions and retention rules.

All people, events, approvals and numbers in this kit are fictional and provided solely for practice. Source material and examples may be adapted for your own internal workshop. No email, publishing, cloud access or model inference is performed by the verifier.
